function [J] = costFun(X,y,w)

N = size(X,1);
error_sq = [];

for i = 1:N
    error_sq = [error_sq ((w'*X(i,:)' - y(i,:))^2)];
end

error_sq = sum(error_sq);
J = error_sq/(2*N);