function [w] = GradientDescent(X,y,w,alpha,NIter)
    
J = [];

for i = 1:NIter
    w = w - alpha * diffCost(X,y,w);
    J = [J costFun(X,y,w)];
end

x = 1:NIter;
figure(2)
plot(x,J);
xlabel('no. of iterations');
ylabel('cost function');
