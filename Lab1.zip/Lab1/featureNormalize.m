function [Xn, mu, sigma] = featureNormalize(X)

mu = mean(X);
X_bar = repmat(mu,size(X,1),1);

X_tilda = X - X_bar;

sigma = std(X);
X_std = repmat(sigma,size(X,1),1);

Xn = X_tilda ./ X_std;

