function w = LinearReg(X,y)

phi = [ones(size(X,1),1) X];

temp = pinv(phi'*phi);

w = temp * phi' * y;

% profit_35 = w(1,:) + w(2,:)*3.5
% profit_70 = w(1,:) + w(2,:)*7.0

